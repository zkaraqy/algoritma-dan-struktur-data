package tugassorting;

public class Sorting {
    private String str;
    private String sortedStr;

    public String getStr() {
        return str;
    }

    public void setStr(String str) {
        this.str = str;
    }
    
    public String getSortedStr() {
        return sortedStr;
    }
    
    public void bubbleSort() {
        if (str == null) {
            return;
        }
    }
    
    public void selectionSort() {
        if (str == null) {
            return;
        }
    }
    
    public void insertionSort() {
        if (str == null) {
            return;
        }
        
    }
    
}
